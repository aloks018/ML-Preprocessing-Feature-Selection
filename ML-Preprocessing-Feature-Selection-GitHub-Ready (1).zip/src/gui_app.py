"""Desktop GUI for exploring the Personalized Diet ML workflow."""
from pathlib import Path
import sys, json, tkinter as tk
from tkinter import ttk, messagebox
import pandas as pd
import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from feature_selection import select_features

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Personalized Diet Recommendation — ML Dashboard")
        self.geometry("1050x700")
        self.df=pd.read_csv(ROOT/"dataset"/"raw_dataset.csv")
        self.selected=["Weight_kg","BMI","Protein_Intake","Dietary_Habits"]
        self.model=None
        self._build()

    def _build(self):
        title=ttk.Label(self,text="Personalized Diet Recommendation | Preprocessing + Feature Selection + Model",font=("Arial",16,"bold"))
        title.pack(pady=12)
        nb=ttk.Notebook(self); nb.pack(fill="both",expand=True,padx=10,pady=10)
        for name, builder in [("Overview",self.overview),("Data Preview",self.data_preview),("Feature Selection",self.selection),("Model Demo",self.model_demo)]:
            f=ttk.Frame(nb); nb.add(f,text=name); builder(f)

    def overview(self,f):
        info=f"""Dataset: Personalized Diet Recommendations
Rows: {len(self.df)}
Columns: {len(self.df.columns)}
Target: Recommended_Meal_Plan
Classes: {', '.join(sorted(self.df['Recommended_Meal_Plan'].dropna().unique()))}
Raw missing values: {int(self.df.isna().sum().sum())}
Exact duplicate rows: {int(self.df.duplicated().sum())}

Workflow:
1. Inspect and validate data
2. Handle missing values (numeric median; categorical Unknown/Not Reported)
3. Remove exact duplicates if present
4. Exclude Patient_ID
5. Exclude recommendation-output columns to avoid leakage
6. Train/test split (80/20)
7. Variance + Pearson redundancy + Chi-Square + ANOVA + Mutual Information
8. Final selected features: {', '.join(self.selected)}
9. Standardize numeric features and one-hot encode categorical features
10. Train Logistic Regression and evaluate on unseen test data"""
        ttk.Label(f,text=info,justify="left",font=("Arial",11)).pack(anchor="nw",padx=20,pady=20)

    def data_preview(self,f):
        cols=list(self.df.columns); tree=ttk.Treeview(f,columns=cols,show="headings",height=22)
        for c in cols: tree.heading(c,text=c); tree.column(c,width=100)
        for _,r in self.df.head(25).iterrows(): tree.insert("", "end", values=[r[c] for c in cols])
        x=ttk.Scrollbar(f,orient="horizontal",command=tree.xview); tree.configure(xscrollcommand=x.set)
        tree.pack(fill="both",expand=True); x.pack(fill="x")

    def selection(self,f):
        selected=self.selected
        _,anova,chi,mi,red=select_features(self.df)
        text="FINAL SELECTION (Notebook decision)\n\n"+"\n".join(f"✓ {x}" for x in selected)
        text+="\n\nNUMERIC ANOVA (p < 0.05 rule)\n"
        text+="\n".join(f"{k}: p={v:.6f}" for k,v in sorted(anova.items(),key=lambda z:z[1])[:10])
        text+="\n\nCATEGORICAL CHI-SQUARE\n"
        text+="\n".join(f"{k}: p={v:.6f}" for k,v in sorted(chi.items(),key=lambda z:z[1]))
        text+="\n\nMUTUAL INFORMATION (bits)\n"
        text+="\n".join(f"{k}: {v:.6f}" for k,v in sorted(mi.items(),key=lambda z:z[1],reverse=True))
        ttk.Label(f,text=text,justify="left",font=("Consolas",10)).pack(anchor="nw",padx=20,pady=15)

    def model_demo(self,f):
        frame=ttk.Frame(f); frame.pack(fill="both",expand=True,padx=20,pady=20)
        ttk.Label(frame,text="Enter patient inputs").grid(row=0,column=0,columnspan=2,pady=8)
        vars={}
        fields=[("Weight_kg","80"),("BMI","27"),("Protein_Intake","120"),("Dietary_Habits","Balanced")]
        for i,(name,default) in enumerate(fields,1):
            ttk.Label(frame,text=name).grid(row=i,column=0,sticky="w",pady=5)
            v=tk.StringVar(value=default); vars[name]=v
            if name=="Dietary_Habits":
                w=ttk.Combobox(frame,textvariable=v,values=["Balanced","Vegetarian","High Protein","Low Carb","Low Fat","Unknown/Not Reported"],width=28)
            else: w=ttk.Entry(frame,textvariable=v,width=30)
            w.grid(row=i,column=1,pady=5)
        out=tk.Text(frame,width=70,height=16); out.grid(row=1,column=3,rowspan=6,padx=30)
        def predict():
            try:
                X=self.df[self.selected].copy(); y=self.df["Recommended_Meal_Plan"]
                num=["Weight_kg","BMI","Protein_Intake"]; cat=["Dietary_Habits"]
                pre=ColumnTransformer([("num",Pipeline([("imp",SimpleImputer(strategy="median")),("scale",StandardScaler())]),num),
                                       ("cat",Pipeline([("imp",SimpleImputer(strategy="most_frequent")),("ohe",OneHotEncoder(handle_unknown="ignore"))]),cat)])
                model=Pipeline([("pre",pre),("clf",LogisticRegression(max_iter=2000,random_state=42))])
                model.fit(X,y)
                row=pd.DataFrame([{"Weight_kg":float(vars["Weight_kg"].get()),"BMI":float(vars["BMI"].get()),
                                   "Protein_Intake":float(vars["Protein_Intake"].get()),"Dietary_Habits":vars["Dietary_Habits"].get()}])
                pred=model.predict(row)[0]; proba=model.predict_proba(row)[0]
                classes=model.named_steps["clf"].classes_
                ranked=sorted(zip(classes,proba),key=lambda z:z[1],reverse=True)
                out.delete("1.0","end"); out.insert("end","MODEL PIPELINE\\n\\nStandardScaler → OneHotEncoder → Logistic Regression\\n\\n")
                out.insert("end",f"Predicted meal plan: {pred}\\n\\nClass probabilities:\\n")
                out.insert("end","\\n".join(f"{c}: {p:.2%}" for c,p in ranked))
                out.insert("end","\\n\\nThis is an educational ML demonstration, not medical advice.")
            except Exception as e: messagebox.showerror("Prediction error",str(e))
        ttk.Button(frame,text="Predict Meal Plan",command=predict).grid(row=6,column=0,columnspan=2,pady=15)
App().mainloop()
